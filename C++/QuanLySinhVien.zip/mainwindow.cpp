#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // test list khi mới tạo ra từ QListWidget
    //ui->lstDSSV->addItem("Nguyễn Thị Tí");
    //ui->lstDSSV->addItem("Hoàng Văn Tèo");

    // Tạo một đối tượng sinhVien thuộc class SinhVien
    SinhVien* sv = new SinhVien();
    sv->nhapTen("Nguyễn Đình Công");
    sv->nhapNgaySinh("20/11/1998");
    sv->nhapGioiTinh("Nam");
    sv->nhapDiem("9");

    // Đưa tên sinh viên ra List
    ui->lstDSSV->addItem((QListWidgetItem*) sv);

}

MainWindow::~MainWindow()
{
    delete ui;
}

// Slot click đúp vào tên sinh viên trong list và hiển thị lên label
void MainWindow::on_lstDSSV_itemDoubleClicked(QListWidgetItem *item)
{
    QString msgThongTin;
    SinhVien* sv = (SinhVien*) item;
    msgThongTin = sv->xuatTen() + " " + sv->xuatNgaySinh() + " " + sv->xuatGioiTinh()+ " " + sv->xuatDiem();
    ui->lblThongTin->setText(msgThongTin);
}
